boxplot(iris$Sepal.Length)

hist(iris$Petal.Length)

barplot(table(iris$Species))

plot(iris$Sepal.Length, type="l")

plot(iris$Sepal.Length, iris$Petal.Length)
