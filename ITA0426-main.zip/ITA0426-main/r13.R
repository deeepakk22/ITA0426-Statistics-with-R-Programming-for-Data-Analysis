arr1 <- array(1:6, dim=c(2,3))
arr2 <- array(7:12, dim=c(2,3))

combined <- rbind(arr1, arr2)
print(combined)
