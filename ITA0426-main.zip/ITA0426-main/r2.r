mat1 <- matrix(1:20, nrow=5, byrow=TRUE,
               dimnames=list(paste0("R",1:5), paste0("C",1:4)))
print(mat1)
mat2 <- matrix(1:9, nrow=3, byrow=FALSE)
print(mat2)
mat3 <- matrix(1:4, nrow=2, byrow=TRUE)
print(mat3)
