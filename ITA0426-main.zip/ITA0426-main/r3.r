arr3d <- array(1:24, dim=c(3,4,2),
               dimnames=list(
                 Rows=c("R1","R2","R3"),
                 Cols=c("C1","C2","C3","C4"),
                 Tables=c("T1","T2")
               ))
print(arr3d)
